javac -d banking/bin $(find banking/src -name *.java)
